package servicio_json;


public class Articulo {
    String Nombre;
    String Descripcion;
    Float Precio;
    Integer Cantidad;
    byte[] foto;
}
