package servicio_json;


public class Carrito {
    Integer ID;
    String Nombre;
    String Descripcion;
    Float Precio;
    Integer Cantidad;
    Integer Cantidad2;
    byte[] foto;
}
