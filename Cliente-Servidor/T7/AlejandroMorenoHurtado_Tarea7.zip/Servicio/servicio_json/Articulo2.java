package servicio_json;


public class Articulo2 {
    Integer ID;
    String Nombre;
    String Descripcion;
    Float Precio;
    Integer Cantidad;
    byte[] foto;
}
