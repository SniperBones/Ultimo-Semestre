/*
  Carlos Pineda Guerrero, noviembre 2022
*/

package servicio_json;

public class ParamAltaUsuario 
{
  Usuario usuario;
}
